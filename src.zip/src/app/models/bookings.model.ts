export interface Booking {
    includes: any;
    _id: string;
    userID: string;
    destinationID: string;
    startDate: string;
    endDate: string;

}