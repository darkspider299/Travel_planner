import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spline',
  templateUrl: './spline.component.html',
  styleUrls: ['./spline.component.css']
})

export class SplineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
